Slower Than Molasses in January - Remotion project (23 shots, 2030 frames @ 30 fps, 1080x1920).
On a PC with Node 20+:  npm ci  &&  npx remotion render src/index.ts MolassesShort out/video.mp4 --codec=h264 --crf=16 --muted
then add the sound:     ffmpeg -i out/video.mp4 -i audio/mix.flac -c:v copy -c:a aac -b:a 192k -shortest final.mp4
