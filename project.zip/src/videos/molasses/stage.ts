// Cast, props and gags per shot: everything that is a card (characters + effect cards) is placed here.
import { INK, SKINS, KID, townsfolk, Outfit, Expr, FrontOpts, SideOpts, Pen, fxBurst, fxPuff } from "./toon";
import { person, blob, lidAt, viewOf, hh, Stage, FxPlace, CamInfo, beginStage, Who } from "./cast";
import * as P from "./props";
import { FPS, SHOTS, CUT, LAB, WALL_Z, BURST_F, POP_F, waveAt, waveH, paintAt, paintX, smooth, clamp01 } from "./story";

const KIDS: Outfit[] = [
  { ...KID, jacket: "#d9a441", cap: "#4a6a8a", skin: SKINS[0] }, { ...KID, jacket: "#6a9a5a", cap: "#b5653f", pants: "#4a4a58", skin: SKINS[1] },
  { ...KID, jacket: "#c25a5a", cap: "#2f5f6a", skin: SKINS[3] }, { ...KID, jacket: "#5a8fc2", cap: "#d9a441", pants: "#5a4a3a", skin: SKINS[2] },
  { ...KID, jacket: "#8a6a4a", cap: "#8c3b4a", skin: SKINS[0] },
];
const BOSS: Outfit = { jacket: "#2f2f3c", pants: "#2a2a34", boots: INK, hat: "tophat", moustache: "#2a201a", build: "stout", skin: SKINS[0], buttons: "#d9c26a" };
const WOMAN: Outfit = { ...townsfolk(1), dress: "#8c3b4a", jacket: "#6a5a7a", skin: SKINS[1] };
const PAINTER: Outfit = { jacket: "#8b93a0", pants: "#6f7683", boots: "#3a2c24", hat: "cap", cap: "#e9e4d6", skin: SKINS[1] };
const WORKERS: Outfit[] = [0, 1, 2, 3].map((v) => ({ jacket: ["#7a5a3a", "#5a6a7a", "#8a7a5a", "#6a4a4a"][v], pants: "#4a4640", boots: "#3a2c24", hat: "cap", cap: ["#4a4a4a", "#6a5a4a", "#3a4a5a", "#5a4a3a"][v], skin: SKINS[v % 4] }));
const LAWYERS: Outfit[] = [
  { jacket: "#33333f", pants: "#22222a", boots: INK, hat: "tophat", moustache: "#2a201a", build: "stout", skin: SKINS[0] },
  { jacket: "#26262e", pants: "#22222a", boots: INK, hat: "tophat", skin: SKINS[2] },
];
const JUDGE: Outfit = { jacket: "#1f1f2a", pants: "#1f1f2a", boots: INK, hat: "hair", hair: "#dcd8d0", skin: SKINS[1], build: "stout" };
const ENGINEER: Outfit = { jacket: "#355c7d", pants: "#3b3f52", boots: "#4a3426", hat: "hair", hair: "#3a2a20", skin: SKINS[2] };
const CROWD: Outfit[] = [townsfolk(0), KIDS[1], townsfolk(1), WORKERS[0], townsfolk(3), KIDS[2], townsfolk(5), WORKERS[2]];

const whos = new Map<string, Who>();
const W = (i: number, o: Outfit): Who => { const k = i + JSON.stringify(o); let w = whos.get(k); if (!w) { w = { i, o, okey: JSON.stringify(o) }; whos.set(k, w); } return w; };

type Opt = { y?: number; expr?: Expr; mode?: FrontOpts["mode"]; phase?: number; look?: number; scale?: number; dx?: number; dz?: number; wave?: number; tilt?: number; headTilt?: number; shadow?: boolean };
const put = (S: Stage, cam: CamInfo, t: number, i: number, o: Outfit, x: number, z: number, op: Opt = {}) => {
  const y = op.y ?? 0, sc = op.scale ?? 1, moving = !!(op.dx || op.dz);
  const view = moving ? viewOf(cam, x, z, op.dx ?? 0, op.dz ?? 0) : { side: false, mirror: false, fs: 1 };
  const bl = lidAt(t, i);
  const fo: FrontOpts = { mode: op.mode ?? "stand", phase: op.phase ?? 0, expr: op.expr ?? "neutral", look: op.look ?? 0, blink: bl, wave: op.wave, tilt: op.tilt, headTilt: op.headTilt };
  const so: SideOpts = { mode: op.mode === "march" || op.mode === "stroll" ? "march" : "stand", phase: op.phase ?? 0, expr: op.expr ?? "neutral", blink: bl, stride: (view as { fs?: number }).fs ?? 1 };
  S.places.push(person(cam, W(i, o), x, y, z, view, fo, so, sc));
  if (op.shadow !== false && y < 0.05) blob(S, x, y, z, sc);
};
const fx = (S: Stage, key: string, cw: number, ch: number, draw: (p: Pen) => void, x: number, y: number, z: number, w: number, h: number, extra: Partial<FxPlace> = {}) =>
  S.fx.push({ key, cw, ch, draw, x, y, z, w, h, ...extra });
const q10 = (v: number) => Math.round(v * 10) / 10;

export const stage = (id: number, f: number, cam: CamInfo): Stage => {
  const S: Stage = { places: [], fx: [] };
  beginStage(cam, SHOTS[id - 1].light);
  const t = f / FPS;
  switch (id) {
    case 1: case 12: {
      // runners flee toward the lens ahead of the wave
      const t0 = id === 1 ? 0 : (f - 890) / FPS;
      for (let k = 0; k < 6; k++) {
        const z = id === 1 ? -6.5 + k * 1.5 + 3.3 * t0 : waveAt(12, f).zf + 3 + k * 1.9;
        if (z > (id === 1 ? 9 : 4.5)) continue;
        const x = (k % 3 - 1) * 1.6 + (k % 2 ? 0.5 : -0.4);
        put(S, cam, t, k, CROWD[k], x, z, { mode: "march", phase: t * 2.2 + k * 0.17, expr: k % 2 ? "shock" : "nervous", dx: 0, dz: 1 });
      }
      if (id === 12 && f < BURST_F + 22) {
        const u = (f - BURST_F) / 22;
        fx(S, `bst|${q10(u * 10)}`, 500, 500, (p) => fxBurst(p, u, "#ffe9b0", 12, 50, 230), 0, 3.2, WALL_Z - 0.3, 9, 9);
        fx(S, `pf|${q10(u * 10)}`, 300, 300, (p) => fxPuff(p, u), -3, 1.2, WALL_Z - 0.2, 5, 4);
      }
      break;
    }
    case 2: for (let k = 0; k < 7; k++) {
      const dir = k % 2 ? 1 : -1;
      put(S, cam, t, k, CROWD[k], (k % 2 ? -3.4 : 3.2) + hh(k) * 0.8, 17 - k * 5 + t * 0.7 * dir, { mode: "stroll", phase: t * 0.8 + k * 0.3, dx: 0, dz: dir });
    } break;
    case 3:
      put(S, cam, t, 2, townsfolk(2), -1.6, -5, { mode: "stroll", phase: t * 0.8, dx: 1, dz: 0 });
      put(S, cam, t, 3, WORKERS[1], 1.4, -9, { expr: "shock", look: 1 });
      break;
    case 4: put(S, cam, t, 20, WORKERS[1], CUT[0] - 3.4, CUT[2] + 5.5, { expr: "shock" }); break;
    case 5: for (let k = 0; k < 4; k++) {
      const u = (t * 0.35 + k * 0.27) % 1;
      fx(S, "drop", 60, 90, P.fxDrop, -1.6 + k * 0.6, 2.7 - u * 2.3, WALL_Z + 0.2, 0.2, 0.3);
    } break;
    case 6: {
      const KX = [-3.6, -2.2, -0.8, 0.7, 2.2];
      for (let k = 0; k < 5; k++) {
        const x = KX[k], z = WALL_Z + 1.0 + (k % 2) * 0.35;
        put(S, cam, t, 10 + k, KIDS[k], x, z, { expr: k === 1 ? "lick" : k % 2 ? "laugh" : "grin" });
        fx(S, "cup", 140, 150, P.fxCup, x + 0.3, 0.8, z - 0.05, 0.3, 0.32);
        const u = (t * 0.5 + k * 0.23) % 1;
        fx(S, "drop", 60, 90, P.fxDrop, x + 0.3, 2.1 - u * 1.2, z - 0.4, 0.12, 0.18);
      }
    } break;
    case 7:
      put(S, cam, t, 30, BOSS, -0.5, -26, { expr: "smile_closed", wave: 1 });
      put(S, cam, t, 31, WOMAN, 0.55, -25.4, { expr: "pained", look: -1 });
      break;
    case 8: case 23: {
      const p = paintAt(id, f), x0 = paintX(id, p);
      fx(S, "ladder", 180, 560, P.fxLadder, x0, 1.85, WALL_Z + 0.45, 1.15, 3.6);
      put(S, cam, t, 40, PAINTER, x0, WALL_Z + 1.3, { y: 1.75, expr: "grin", shadow: false });
      const sw = Math.sin(t * 7);
      fx(S, "brush", 120, 280, P.fxBrush, x0 + 0.5 + 0.2 * sw, 3.5 + 0.12 * sw, WALL_Z + 1.5, 0.3, 0.68, { rot: 0.3 * sw });
      fx(S, "bucket", 160, 140, P.fxBucket, x0 + 1.0, 0.18, WALL_Z + 1.4, 0.4, 0.35);
      break;
    }
    case 9:
      put(S, cam, t, 30, BOSS, 0, -26.5, { expr: "smile_closed" });
      fx(S, "plan", 340, 440, P.fxPlan, 0.1, 1.0, -26.1, 0.6, 0.77, { rot: Math.PI });
      put(S, cam, t, 14, KIDS[3], 0.7, -27.2, { expr: "smile", look: -1, headTilt: 0.15 });
      break;
    case 10: {
      const WX = [-3.2, -1.6, 2.0, 3.5];
      for (let k = 0; k < 4; k++) {
        put(S, cam, t, 50 + k, WORKERS[k], WX[k], -27.6 + (k % 2) * 0.5, { expr: k % 2 ? "grin" : "smile" });
        fx(S, "crate", 360, 300, P.fxCrate, WX[k] + 0.6, 0.35, -27.5 + (k % 2) * 0.5, 0.7, 0.58);
      }
      if (f >= POP_F - 1 && f < POP_F + 14) { const u = (f - POP_F) / 14; fx(S, `bst|${q10(u * 10)}`, 500, 500, (p) => fxBurst(p, u, "#fff3b0", 10, 40, 230), -0.4, 2.3, WALL_Z + 0.25, 1.7, 1.7); }
      break;
    }
    case 11: {
      put(S, cam, t, 14, KIDS[3], 0.4, -24.2, { expr: "nervous", look: 1, headTilt: -0.2 });
      fx(S, "cup", 140, 150, P.fxCup, 0.7, 0.8, -24.25, 0.3, 0.32);
      const g = smooth((f - 836) / 40);
      if (g > 0.02) fx(S, "crack", 220, 460, P.fxCrack, 0.3, 12.3, WALL_Z + 0.2, 2.6 * g, 6 * g);
      break;
    }
    case 13: {
      const w = waveAt(13, f);
      const n = Math.max(0, Math.min(21, Math.floor((f - 1000) / 2.3)));
      for (let k = 0; k < n; k++) {
        const z = -15 + (k % 7) * 3.0 + hh(k, 5) * 1.3, x = (hh(k, 3) - 0.5) * 7.2;
        if (z < w.zf - 0.5) fx(S, "hat", 220, 130, P.fxHat, x, waveH(w, z) + 0.12, z, 0.8, 0.47);
      }
      for (let k = 0; k < 4; k++) put(S, cam, t, k, CROWD[k], (k - 1.5) * 1.5, w.zf + 4 + k * 2.4, { mode: "march", phase: t * 2.2 + k * 0.2, expr: "shock", dx: 0, dz: 1 });
      break;
    }
    case 14: fx(S, "snail", 340, 220, P.fxSnail, 0.05, 0.19, 4 + (f - 1094) * 0.002, 0.7, 0.45); break;
    case 15: {
      const w = waveAt(15, f);
      const hit = w.zf > 4 ? w.zf - 4 : 0;
      const z = 4 + hit * 0.9, y = Math.max(0.19, hit > 0 ? waveH(w, z) + 0.2 : 0.19);
      fx(S, "snail", 340, 220, P.fxSnail, 0.05, y, z, 0.7, 0.45, { rot: hit > 0 ? hit * 0.5 : 0 });
      break;
    }
    case 16:
      put(S, cam, t, 60, LAWYERS[0], -0.85, -6.4, { expr: "grin", wave: 1 });
      put(S, cam, t, 61, LAWYERS[1], 0.85, -6.6, { expr: "stern", wave: 1 });
      fx(S, "bomb", 220, 280, P.fxBomb, 0, 0.5, -6.0, 0.7, 0.89, { rot: 0.05 * Math.sin(t * 9) });
      break;
    case 17: {
      put(S, cam, t, 70, JUDGE, -9.5, -33.9, { expr: "stern", look: -1 });
      const g = smooth((f - 1340) / 50);
      if (g > 0.02) fx(S, "scrape", 300, 220, P.fxScrape, -8.3, 1.3, -34.6, 1.8 * g, 1.3 * g);
      break;
    }
    case 18:
      if (f < 1466) fx(S, `spoon|${q10(smooth((f - 1419) / 40) * 10)}`, 220, 440, (p) => P.fxSpoon(p, smooth((f - 1419) / 40)), LAB[0], 1.15, LAB[2], 0.9, 1.8);
      else {
        const u = smooth((f - 1470) / 40);
        fx(S, "crate", 360, 300, P.fxCrate, LAB[0] + 0.7 * u, 0.7, LAB[2], 1.5, 1.25);
        put(S, cam, t, 14, KIDS[3], LAB[0] - 1.2 + 0.7 * u, LAB[2] + 0.1, { expr: "pained", tilt: 0.25 });
        put(S, cam, t, 15, KIDS[4], LAB[0] - 2.0 + 0.7 * u, LAB[2] + 0.1, { expr: "pained", tilt: 0.25 });
      }
      break;
    case 19: {
      const gentle = Math.sin(clamp01((f - 1522) / 40) * Math.PI * 3) * 0.04 * (f < 1570 ? 1 : 0);
      const hard = (f > 1596 && f < 1608) ? 0.2 : 0;
      fx(S, "packet", 200, 360, P.fxPacket, LAB[0] - 0.3, 0.72, LAB[2], 0.5 * (1 - gentle - hard), 0.9 * (1 + gentle * 0.5));
      const u = clamp01((f - 1606) / 16), hit = f >= 1622;
      if (u > 0) fx(S, `sq|${q10(u * 10)}`, 640, 300, (p) => P.fxSquirt(p, u), LAB[0] + 0.85, 1.48, LAB[2], 2.6, 1.2);
      put(S, cam, t, 14, KIDS[2], LAB[0] + 1.95, LAB[2] + 0.05, { expr: hit ? "shock" : "neutral" });
      if (hit) fx(S, "splat", 300, 300, P.fxSplat, LAB[0] + 1.95, 1.15, LAB[2] + 0.1, 0.6, 0.6);
      break;
    }
    case 20: if (f >= 1745) {
      const cp = cam.pos, px = cp.x + (CUT[0] - cp.x) * 0.55, pz = cp.z + (CUT[2] - cp.z) * 0.55;
      fx(S, "plates", 700, 460, P.fxPlates, px, 3.6, pz, 7.5, 4.9);
    } break;
    case 21:
      fx(S, "table", 760, 340, P.fxTable, 0, 0.45, -2.9, 2.0, 0.9);
      put(S, cam, t, 80, ENGINEER, 0, -3.5, { expr: "smile_closed", headTilt: 0.1 });
      fx(S, "plan", 340, 440, P.fxPlan, 0.1, 1.02, -2.85, 0.55, 0.7);
      put(S, cam, t, 81, townsfolk(4), -2.8, -9, { mode: "stroll", phase: t * 0.8, dx: 0, dz: 1 });
      break;
    case 22: {
      fx(S, "plan", 340, 440, P.fxPlan, 0, 0.95, -2, 1.1, 1.42);
      const down = smooth((f - 1900) / 22), up = smooth((f - 1928) / 14);
      if (f < 1990) fx(S, "stamp", 220, 320, P.fxStamp, 0.05, 1.65 - 0.55 * down + 0.4 * up, -1.95, 0.5, 0.73);
      if (f >= 1926) fx(S, "seal", 280, 280, P.fxSeal, 0, 0.95, -1.97, 0.8, 0.8);
      put(S, cam, t, 80, ENGINEER, 0.2, -4.5, { expr: "smile_closed" });
      break;
    }
  }
  return S;
};
