// Effect-card drawings for the molasses short (props, gags, inserts). Each draws on its own canvas (pixel units, y down).
import { Pen, INK } from "./toon";
type P2 = [number, number];
const rr = (x0: number, y0: number, x1: number, y1: number, r: number): P2[] =>
  [[x0 + r, y0], [x1 - r, y0], [x1, y0 + r], [x1, y1 - r], [x1 - r, y1], [x0 + r, y1], [x0, y1 - r], [x0, y0 + r]];
const MOL = "#5b2f14", MOL_HI = "#a8642e";

/** tin cup 140 x 150 */
export const fxCup = (p: Pen) => {
  p.ell(112, 82, 24, 28, null, 8, -80, 80);
  p.poly([[26, 30], [114, 30], [100, 132], [40, 132]], "#b9c0c9", 8);
  p.poly([[22, 24], [118, 24], [118, 42], [22, 42]], "#dfe4ea", 7);
  p.poly([[46, 60], [56, 60], [60, 116], [52, 116]], "#f1f4f8", 0);
  p.ell(70, 34, 40, 6, MOL, 0);
  p.ell(66, 31, 14, 2.5, MOL_HI, 0);
};
/** cartoon bomb 220 x 280 */
export const fxBomb = (p: Pen) => {
  p.line([[118, 62], [128, 36], [112, 20], [126, 4]], "#c9a45a", 6);
  p.ell(110, 170, 86, 86, "#2a2a33", 9);
  p.ell(78, 138, 22, 14, "#6a6a78", 0, 0, 360, -35);
  p.poly([[96, 70], [124, 70], [124, 90], [96, 90]], "#47474f", 7);
  for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; p.stroke([[126 + 8 * Math.cos(a), 6 + 8 * Math.sin(a)], [126 + 26 * Math.cos(a), 6 + 26 * Math.sin(a)]], 5, "#ffb62e"); }
};
/** snail 300 x 220 */
export const fxSnail = (p: Pen) => {
  p.poly([[20, 190], [250, 190], [280, 160], [262, 120], [236, 150], [200, 150], [60, 150], [30, 170]], "#d8c7a0", 9);
  p.line([[250, 134], [262, 86]], "#d8c7a0", 7); p.line([[268, 130], [292, 90]], "#d8c7a0", 7);
  p.dot(262, 84, 7, INK); p.dot(292, 88, 7, INK); p.dot(266, 150, 4, INK);
  p.ell(120, 100, 84, 82, "#a8683a", 9);
  p.ell(120, 100, 54, 52, null, 6); p.ell(124, 100, 28, 26, null, 6); p.ell(120, 98, 8, 8, INK, 0);
};
/** ketchup packet (no text) 200 x 360 */
export const fxPacket = (p: Pen) => {
  p.poly(rr(26, 20, 174, 340, 8), "#d62f26", 9);
  for (let i = 0; i < 6; i++) { p.stroke([[26 + i * 25, 20], [38 + i * 25, 34]], 6); p.stroke([[26 + i * 25, 340], [38 + i * 25, 326]], 6); }
  p.ell(100, 180, 44, 44, "#f3efe6", 7);
  p.poly([[100, 150], [118, 168], [108, 168], [108, 212], [92, 212], [92, 168], [82, 168]], "#d62f26", 6);
  p.poly([[40, 60], [52, 60], [52, 300], [40, 300]], "#f06a58", 0);
};
/** ketchup squirt arc, u = 0..1 grows from the left end 640 x 300 */
export const fxSquirt = (p: Pen, u: number) => {
  const pts: P2[] = [];
  const n = Math.max(2, Math.round(40 * u));
  for (let i = 0; i <= n; i++) { const s = (i / 40); pts.push([30 + s * 560, 250 - 150 * s - 90 * s * (1 - s) * 3 + 120 * s * s]); }
  if (pts.length > 1) { p.stroke(pts, 40, INK); p.stroke(pts, 28, "#d62f26"); p.stroke(pts, 8, "#f27a68"); }
  for (let i = 0; i < 5; i++) { const q = pts[Math.min(pts.length - 1, Math.round(pts.length * (0.3 + i * 0.15)))]; p.dot(q[0] + 10, q[1] - 22 - 8 * i, 8, "#d62f26"); }
};
export const fxSplat = (p: Pen) => {
  const pts: P2[] = []; for (let i = 0; i < 28; i++) { const a = (i / 28) * Math.PI * 2, r = i % 2 ? 70 : 118 + (i % 5) * 10; pts.push([150 + r * Math.cos(a), 150 + r * Math.sin(a)]); }
  p.poly(pts, "#d62f26", 8); p.ell(110, 108, 26, 14, "#f27a68", 0, 0, 360, -30);
  p.dot(40, 60, 10, "#d62f26"); p.dot(262, 240, 12, "#d62f26"); p.dot(250, 48, 8, "#d62f26");
};
/** spoon with a molasses string, ooze 0..1, 220 x 440 */
export const fxSpoon = (p: Pen, ooze: number) => {
  p.poly([[100, 160], [120, 160], [128, 420], [92, 420]], "#c9ced6", 8);
  p.ell(110, 100, 64, 76, "#d5dae1", 9);
  p.ell(110, 108, 52, 62, MOL, 5);
  const len = 40 + 150 * ooze;
  p.poly([[96, 160], [124, 160], [118, 160 + len * 0.6], [112, 160 + len], [104, 160 + len * 0.6]], MOL, 6);
  p.ell(110, 160 + len + 12, 15, 20, MOL, 6);
  p.ell(96, 92, 14, 22, MOL_HI, 0, 0, 360, 20);
};
/** blueprint sheet 340 x 440 (no text) */
export const fxPlan = (p: Pen) => {
  p.poly(rr(14, 14, 326, 426, 6), "#3f73b8", 9);
  for (let i = 1; i < 6; i++) { p.stroke([[30, 14 + i * 68], [310, 14 + i * 68]], 2, "#9cc0ea"); }
  for (let i = 1; i < 5; i++) { p.stroke([[14 + i * 62, 30], [14 + i * 62, 410]], 2, "#9cc0ea"); }
  p.poly([[70, 340], [270, 340], [270, 220], [170, 140], [70, 220]], null, 5); p.stroke([[70, 340], [270, 340], [270, 220], [170, 140], [70, 220], [70, 340]], 6, "#f0f4fa");
  p.ell(170, 270, 30, 30, null, 5);
};
/** wooden ladder 180 x 560 */
export const fxLadder = (p: Pen) => {
  p.poly([[30, 20], [52, 20], [66, 540], [40, 540]], "#b98a55", 8); p.poly([[128, 20], [150, 20], [140, 540], [114, 540]], "#b98a55", 8);
  for (let i = 0; i < 8; i++) { const y = 70 + i * 62; p.poly([[44, y], [136, y], [136, y + 16], [44, y + 16]], "#d1a56d", 6); }
};
export const fxBucket = (p: Pen) => {
  p.ell(80, 40, 50, 14, null, 7, 180, 360);
  p.poly([[26, 50], [134, 50], [118, 134], [42, 134]], "#8a8f98", 8);
  p.ell(80, 52, 54, 12, "#6a3a1c", 7);
};
/** paintbrush 120 x 280, tip down */
export const fxBrush = (p: Pen) => {
  p.poly([[50, 10], [70, 10], [74, 150], [46, 150]], "#c28a4c", 7);
  p.poly([[40, 150], [80, 150], [80, 176], [40, 176]], "#aeb3bb", 6);
  p.poly([[38, 176], [82, 176], [90, 244], [60, 262], [30, 244]], "#6a3a1c", 7);
};
export const fxCrate = (p: Pen) => {
  p.poly(rr(14, 20, 346, 286, 6), "#b98a55", 9);
  p.stroke([[14, 108], [346, 108]], 7); p.stroke([[14, 198], [346, 198]], 7);
  p.stroke([[24, 30], [336, 276]], 7); p.stroke([[336, 30], [24, 276]], 7);
};
/** rubber stamp 220 x 320 */
export const fxStamp = (p: Pen) => {
  p.ell(110, 70, 36, 40, "#8a4a2a", 8);
  p.poly([[96, 100], [124, 100], [128, 190], [92, 190]], "#a05c36", 8);
  p.poly(rr(30, 190, 190, 250, 10), "#2f3b52", 8);
  p.poly(rr(46, 250, 174, 290, 8), "#d2d6de", 7);
};
/** approval seal (star in a ring, no text) 280 x 280 */
export const fxSeal = (p: Pen) => {
  const pts: P2[] = []; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i / 10) * Math.PI * 2, r = i % 2 ? 36 : 84; pts.push([140 + r * Math.cos(a), 140 + r * Math.sin(a)]); }
  p.ell(140, 140, 120, 120, null, 10); p.ell(140, 140, 100, 100, null, 6);
  p.poly(pts, "#c0302c", 7);
};
/** drafting table 760 x 340 */
export const fxTable = (p: Pen) => {
  p.poly([[40, 60], [720, 60], [760, 140], [0, 140]], "#c9a06a", 9);
  p.poly([[0, 140], [760, 140], [760, 176], [0, 176]], "#9a6f40", 8);
  for (const x of [50, 690]) p.poly([[x - 16, 176], [x + 16, 176], [x + 12, 330], [x - 12, 330]], "#7a5530", 8);
};
/** bowler hat 220 x 130 */
export const fxHat = (p: Pen) => {
  p.ell(110, 92, 100, 22, "#1f1f28", 8);
  p.poly([[44, 90], [60, 30], [160, 30], [176, 90]], "#2a2a34", 8); p.ell(110, 30, 50, 12, "#2a2a34", 8);
  p.stroke([[46, 74], [174, 74]], 8, "#6a2f2f");
};
export const fxDrop = (p: Pen) => { p.poly([[30, 6], [52, 52], [50, 74], [30, 84], [10, 74], [8, 52]], MOL, 7); p.ell(22, 62, 5, 8, MOL_HI, 0); };
/** zig-zag crack 220 x 460 */
export const fxCrack = (p: Pen) => {
  const z: P2[] = [[110, 10], [86, 90], [130, 160], [78, 250], [138, 330], [104, 450]];
  p.stroke(z, 22, INK); p.stroke(z, 9, "#2b1608");
};
/** scraped patch showing grey steel 300 x 220 */
export const fxScrape = (p: Pen) => {
  p.poly([[20, 60], [90, 14], [220, 28], [284, 90], [262, 190], [140, 206], [40, 170]], "#8a929e", 8);
  for (let i = 0; i < 6; i++) p.stroke([[40 + i * 38, 60 + (i % 2) * 20], [60 + i * 38, 170]], 3, "#a9b0ba");
  p.dot(60, 90, 5); p.dot(240, 150, 5);
};
/** thick vs thin steel plate gauge 700 x 460 (no text) */
export const fxPlates = (p: Pen) => {
  p.poly(rr(60, 80, 280, 400, 4), "#9aa3b0", 9); p.poly(rr(400, 80, 442, 400, 3), "#9aa3b0", 9);
  for (let i = 0; i < 5; i++) { p.stroke([[40, 100 + i * 70], [60, 100 + i * 70]], 5); p.stroke([[600, 100 + i * 70], [640, 100 + i * 70]], 5); }
  p.stroke([[640, 80], [640, 400]], 6);
  p.stroke([[300, 240], [380, 240]], 6); p.poly([[380, 226], [398, 240], [380, 254]], INK, 0);
  p.poly([[520, 210], [570, 260], [520, 310]], "#d62f26", 7);
};
