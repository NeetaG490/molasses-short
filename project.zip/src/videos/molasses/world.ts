// The molasses world as one three.js scene: North End street 1919, the riveted tank (intact -> brown -> wreck), the
// molasses wave (a displaced grid), a cutaway tank for the explainer shots, sky + light rig, and the cast cards.
// update(id, f, camera) poses everything for shot `id` at frame f (pure function of id + f).
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { staticFile } from "remotion";
import { Batch, boxGeo, V, lam, Kit, kitClone, prop, house } from "./build";
import { ctex, rep, cobbleHD, stoneHD, cloudHD } from "./paint";
import { LIGHTS, LOOK, LightPreset } from "./lights";
import { TONE, CHAR, twoTone, untone } from "./shade";
import { NOINK } from "./ink";
import { Pool, Actor, Fx } from "./cast";
import { stage } from "./stage";
import { SHOTS, TANK, TANK_R, TANK_H, WALL_Z, CUT, camAt, waveAt, waveH, WaveState, tankState, paintAt, paintX, bulgeAt, FOREGROUND, ShotDef, BURST_F, POP_F, smooth } from "./story";

const KENNEY = ["tree_oak", "tree_default", "tree_detailed", "tree_fat", "tree_cone", "tree-high-round", "tree", "plant_bushLarge", "plant_bushDetailed",
  "plant_bush", "hedge", "flower_redA", "flower_yellowA", "flower_purpleA", "grass_large", "grass", "lily_large", "lantern", "cart", "stall-red",
  "stall-green", "stall-bench", "banner-red", "banner-green", "windmill", "canoe"];
let kitP: Promise<Kit> | null = null;
export const loadKit = () => {
  if (!kitP) {
    const loader = new GLTFLoader();
    kitP = Promise.all(KENNEY.map((n) => loader.loadAsync(staticFile(`bridge/kenney/${n}.glb`)).then((g) => [n, g.scene] as const).catch(() => [n, null] as const)))
      .then((list) => Object.fromEntries(list.filter((e) => e[1]).map(([n, s]) => [n, s!])) as Kit);
  }
  return kitP;
};

const discTex = () => ctex("sunDisc", 128, 128, (g) => {
  const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
});
const haloTex = () => ctex("sunHalo", 256, 256, (g) => {
  const im = g.createImageData(256, 256);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const u = Math.hypot(x - 127.5, y - 127.5) / 128;
    const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
    const i = (y * 256 + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
  }
  g.putImageData(im, 0, 0);
});
function quadUp(x0: number, x1: number, z0: number, z1: number, u: number, v: number, dy = 0) {
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute([x0, dy, z1, x1, dy, z1, x1, dy, z0, x0, dy, z1, x1, dy, z0, x0, dy, z0], 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute([0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0], 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute([0, 0, u, 0, u, v, 0, 0, u, v, 0, v], 2));
  return g;
}

/** riveted steel plates, one 5.4 m tile: 3 plate rows, staggered vertical seams, rivets, molasses weep streaks */
const steelTex = (brown: boolean) => ctex(brown ? "tankBrownHD" : "tankSteelHD", 2048, 2048, (g, r) => {
  const cols = brown ? ["#b2701f", "#a6671b"] : ["#a3a79f", "#989d95"], seam = brown ? "#5a2a10" : "#4a4a48";
  const rows = 3, ph = 2048 / rows;
  for (let j = 0; j < rows; j++) for (let i = -1; i < 3; i++) { g.fillStyle = cols[(i + j + 2) % 2]; g.fillRect(i * 1024 + (j % 2) * 512, j * ph, 1024, ph); }
  g.strokeStyle = seam; g.lineWidth = 7;
  const riv = (x: number, y: number) => {
    g.fillStyle = seam; g.beginPath(); g.arc(x, y, 11, 0, 7); g.fill();
    g.fillStyle = brown ? "#b9824f" : "#c9d0da"; g.beginPath(); g.arc(x - 3, y - 3, 6, 0, 7); g.fill();
  };
  const weeps: [number, number][] = [];
  for (let j = 0; j < rows; j++) {
    const y = j * ph;
    g.beginPath(); g.moveTo(0, y); g.lineTo(2048, y); g.stroke();
    for (let x = 14; x < 2048; x += 58) { riv(x, y + 16); if (r() < 0.16) weeps.push([x, y + 16]); }
    for (let i = 0; i < 3; i++) {
      const x = i * 1024 + (j % 2) * 512; g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + ph); g.stroke();
      for (let yy = y + 30; yy < y + ph - 10; yy += 58) { riv(x + 16, yy); if (r() < 0.04) weeps.push([x + 16, yy]); }
    }
  }
  g.lineCap = "round";
  for (const [x, y] of weeps) {
    const len = 260 + r() * 560; g.strokeStyle = brown ? "#6b3510" : "#9a5424"; g.lineWidth = 16 + r() * 8;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + (r() - 0.5) * 8, y + len); g.stroke();
    g.fillStyle = g.strokeStyle; g.beginPath(); g.arc(x, y + len, 17, 0, 7); g.fill();
    g.strokeStyle = brown ? "#a8642e" : "#e0a35a"; g.lineWidth = 4; g.beginPath(); g.moveTo(x - 4, y + 10); g.lineTo(x - 4, y + len * 0.8); g.stroke();
  }
});

/** molasses: warm caramel gradient with lighter swirls and glossy streak highlights (one 2.2 m tile) */
const molTex = () => ctex("molasses", 512, 512, (g, r) => {
  const gr = g.createLinearGradient(0, 0, 0, 512); gr.addColorStop(0, "#6a3212"); gr.addColorStop(0.5, "#4e240c"); gr.addColorStop(1, "#6a3212");
  g.fillStyle = gr; g.fillRect(0, 0, 512, 512);
  g.lineCap = "round";
  for (let i = 0; i < 26; i++) { g.strokeStyle = r() < 0.5 ? "#8a4a1e" : "#3a1a08"; g.globalAlpha = 0.5; g.lineWidth = 8 + r() * 22;
    const y = r() * 512, x = r() * 512; g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x + 90, y - 40 * r(), x + 170, y + 50 * r(), x + 260 * r() + 80, y + 10); g.stroke(); }
  g.globalAlpha = 0.85;
  for (let i = 0; i < 14; i++) { g.strokeStyle = "#e6b878"; g.lineWidth = 2 + r() * 3; const y = r() * 512, x = r() * 512; g.beginPath(); g.moveTo(x, y); g.lineTo(x + 50 + r() * 90, y + (r() - 0.5) * 12); g.stroke(); }
  g.globalAlpha = 1;
});

const NX = 12, NZ = 240, XH = 5.2, ZA = -44, ZB = 44, DX = (2 * XH) / NX, DZ = (ZB - ZA) / NZ;
const GAP = 0.62;
/** world-space tank UVs: u = angle / 2pi (so strips, wreck and wall all share the same plate pattern), v = height / TANK_H */
const tankUV = (g: THREE.BufferGeometry) => {
  const p = g.attributes.position as THREE.BufferAttribute, uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) uv.setXY(i, Math.atan2(p.getX(i) - TANK[0], p.getZ(i) - TANK[2]) / (Math.PI * 2), p.getY(i) / TANK_H);
  uv.needsUpdate = true;
}; // half-angle of the hole the wave leaves in the tank wall

export class World {
  root = new THREE.Group();
  private pool = new Pool();
  private actors: Actor[] = [];
  private fxs: Fx[] = [];
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight; private fill: THREE.DirectionalLight;
  private sky: THREE.Mesh; private skyMat: THREE.ShaderMaterial;
  private fog = new THREE.Fog("#bccbec", 25, 420);
  private sunDisc: THREE.Sprite; private sunHalo: THREE.Sprite;
  private sunCache = new Map<number, THREE.Vector3>();
  private cloudMaps: Record<"day" | "golden", THREE.Texture[]>;
  private clouds: THREE.Mesh[] = [];
  private fgs: { o: THREE.Object3D; a: number; b: number }[] = [];
  private frustum = new THREE.Frustum();
  private m4 = new THREE.Matrix4(); private v = new THREE.Vector3(); private sph = new THREE.Sphere();
  // tank
  private steelM: THREE.Material; private brownM: THREE.Material;
  private tankWall: THREE.Mesh; private tankWreck: THREE.Mesh; private tankRoof: THREE.Mesh; private tankPool: THREE.Mesh;
  private strips: THREE.Mesh[] = []; private stripX: number[] = [];
  private domes: THREE.Mesh[] = []; private jet: THREE.Mesh;
  // wave + hero house + cutaway
  private waveGeo: THREE.BufferGeometry; private waveMesh: THREE.Mesh;
  private heroHouse = new THREE.Group();
  private cutGroup = new THREE.Group(); private cutWall: THREE.Mesh; private cutFill: THREE.Mesh;

  constructor(kit: Kit) {
    const R = this.root;
    // ---- sky + light (same rig as the bridge short) ----
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() }, c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el)); c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el)); c = mix(c, c4, smoothstep(e.z, e.w, el)); gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK); R.add(this.sky);
    this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: discTex(), color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true, transparent: true, blending: THREE.AdditiveBlending }));
    this.sunDisc.renderOrder = -0.5; this.sunHalo.renderOrder = 5;
    for (const m of [this.sunDisc, this.sunHalo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#fff0d6", 2.6); this.sun.castShadow = true; this.sun.shadow.mapSize.set(4096, 4096);
    this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
    R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
    this.cloudMaps = { day: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.day.cloud)), golden: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.golden.cloud)) };
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3, d = 620 + (i % 3) * 60;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.cloudMaps.day[i % 4], color: new THREE.Color(1.1, 1.1, 1.1), transparent: true, depthWrite: false, fog: false }));
      const w = 130 + (i % 4) * 30; m.position.set(Math.cos(a) * d, 120 + (i % 4) * 38, Math.sin(a) * d); m.scale.set(w, w / 2, 1); m.layers.set(NOINK);
      this.clouds.push(m); R.add(m);
    }

    // ---- ground, street, houses, props (static batch) ----
    const b = new Batch();
    const M: Record<string, THREE.Material> = {
      ground: lam("groundWinter", () => ({ color: "#d6d0c2" })),
      cobble: lam("cobbleHD", () => ({ map: cobbleHD() })),
      cope: lam("copeHD", () => ({ map: stoneHD("copeHD", ["#e6dccd", "#ddd3c3", "#ece4d6", "#d6cbba"], "#aea293") })),
    };
    b.add(quadUp(-700, 700, -700, 700, 1, 1), M.ground);
    b.add(quadUp(-5.5, 5.5, -36, 70, 2.75, 26.5, 0.012), M.cobble);
    for (const s of [-1, 1]) b.add(quadUp(s * 5.5 - (s > 0 ? 0 : 1.7), s * 5.5 + (s > 0 ? 1.7 : 0), -36, 70, 0.5, 26, 0.02), M.cope);
    b.add(quadUp(-60, 60, -36, -30, 14, 1.5, 0.008), M.cobble);
    const ZH = [-24, -15.5, -7, 1.5, 10, 18.5, 27, 35.5, 44, 52.5, 61];
    ZH.forEach((z, k) => {
      const hs = [7, 8.4, 9.8, 8.4, 7, 9.8][k % 6];
      if (k === 2) { b.add(boxGeo(V(-12.6, 0, z - 4.1), V(-5.6, 0.35, z + 4.1), 2), M.cope); return; } // foundation of the house the wave moves
      house(b, -9.1, z, Math.PI / 2, 8, 7, hs, k);
    });
    ZH.forEach((z, k) => house(b, 9.1, z + 2.2, -Math.PI / 2, 8, 7, [8.4, 7, 9.8, 7, 8.4][k % 5], k + 3));
    for (let k = 0; k < 8; k++) for (const s of [-1, 1]) prop(b, kit, "lantern", s * 5.0, 0, -25 + k * 12 + (s > 0 ? 6 : 0), 3.4, s > 0 ? Math.PI / 2 : -Math.PI / 2);
    prop(b, kit, "stall-red", -4.2, 0, -26.5, 2.6, Math.PI / 2);
    prop(b, kit, "stall-green", 4.3, 0, -27.5, 2.6, -Math.PI / 2);
    prop(b, kit, "stall-bench", 3.6, 0, -22, 1.0, 0.3);
    prop(b, kit, "cart", -3.0, 0, -13, 1.5, 0.4);
    b.build(R);
    // the house the wave shoves off its foundation: its own group
    const hb = new Batch(); house(hb, 0, 0, Math.PI / 2, 8, 7, 9.8, 2); hb.build(this.heroHouse);
    this.heroHouse.position.set(-9.1, 0, ZH[2]); R.add(this.heroHouse);

    // ---- the tank ----
    this.steelM = lam("tankSteelHD", () => ({ map: rep(steelTex(false), 16, 2.78), side: THREE.DoubleSide }));
    this.brownM = lam("tankBrownHD", () => ({ map: rep(steelTex(true), 16, 2.78), side: THREE.DoubleSide }));
    const body = (thS: number, thL: number) => { const g = new THREE.CylinderGeometry(TANK_R, TANK_R, TANK_H, 96, 1, true, thS, thL); g.translate(TANK[0], TANK_H / 2, TANK[2]); tankUV(g); return g; };
    this.tankWall = new THREE.Mesh(body(0, Math.PI * 2), this.steelM);
    this.tankWreck = new THREE.Mesh(body(GAP, Math.PI * 2 - 2 * GAP), this.steelM);
    const roof = new THREE.ConeGeometry(TANK_R, 1.3, 96, 1, false); roof.translate(TANK[0], TANK_H + 0.65, TANK[2]);
    this.tankRoof = new THREE.Mesh(roof, this.steelM);
    const pg = new THREE.CircleGeometry(TANK_R - 0.1, 64); pg.rotateX(-Math.PI / 2); pg.translate(TANK[0], 0.5, TANK[2]);
    const waveM = twoTone(new THREE.MeshPhongMaterial({ map: rep(molTex(), 1, 1), specular: "#ffe0aa", shininess: 80, emissive: "#4a2209" }), 0.2);
    this.tankPool = new THREE.Mesh(pg, waveM);
    for (const m of [this.tankWall, this.tankWreck, this.tankRoof, this.tankPool]) { m.castShadow = true; m.receiveShadow = true; R.add(m); }
    // brown paint strips (4 deg each, +-48 deg around the street side), a painted band 0.3..5.6 m
    const N = 24;
    for (let i = 0; i < N; i++) {
      const th0 = -0.84 + (i / N) * 1.68, g = new THREE.CylinderGeometry(TANK_R + 0.04, TANK_R + 0.04, 5.3, 4, 1, true, th0, 1.68 / N + 0.004);
      g.translate(TANK[0], 3.0, TANK[2]); tankUV(g);
      const m = new THREE.Mesh(g, this.brownM); m.receiveShadow = true; m.visible = false; R.add(m);
      this.strips.push(m); this.stripX.push(TANK_R * Math.sin(th0 + 0.84 / N));
    }
    // rivet domes + the jet that blows out of the popped one (shots 10-11)
    const domeM = twoTone(new THREE.MeshPhongMaterial({ color: "#d9955a", specular: "#fff0d8", shininess: 50 }), 0.15);
    const DP: [number, number][] = [[-0.4, 2.3], [-0.9, 2.05], [0.15, 2.0], [-0.5, 1.6], [0.0, 2.7], [-1.1, 2.7], [0.5, 2.35]];
    for (const [x, y] of DP) {
      const d = new THREE.Mesh(new THREE.SphereGeometry(0.1, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), domeM);
      d.rotation.x = Math.PI / 2; d.position.set(x, y, TANK[2] + Math.sqrt(TANK_R * TANK_R - x * x) + 0.01); d.visible = false; d.castShadow = true;
      this.domes.push(d); R.add(d);
    }
    this.jet = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.12, 1, 8), waveM);
    this.jet.visible = false; R.add(this.jet);

    // ---- the wave (displaced grid) ----
    const wg = new THREE.BufferGeometry(), pos = new Float32Array((NX + 1) * (NZ + 1) * 3), uv = new Float32Array((NX + 1) * (NZ + 1) * 2), idx: number[] = [];
    for (let j = 0; j <= NZ; j++) for (let i = 0; i <= NX; i++) { const k = j * (NX + 1) + i; uv[k * 2] = i / NX; uv[k * 2 + 1] = j / 6; pos[k * 3] = -XH + i * DX; pos[k * 3 + 2] = ZA + j * DZ; }
    for (let j = 0; j < NZ; j++) for (let i = 0; i < NX; i++) { const a = j * (NX + 1) + i, c = a + NX + 1; idx.push(a, c, a + 1, a + 1, c, c + 1); }
    wg.setAttribute("position", new THREE.BufferAttribute(pos, 3)); wg.setAttribute("uv", new THREE.BufferAttribute(uv, 2)); wg.setIndex(idx);
    this.waveGeo = wg;
    this.waveMesh = new THREE.Mesh(wg, waveM); this.waveMesh.frustumCulled = false; this.waveMesh.castShadow = true; this.waveMesh.receiveShadow = true; R.add(this.waveMesh);

    // ---- cutaway tank for the explainer shots (open front, molasses visible inside) ----
    const cr = 6.2, ch = 6.75;
    const cw = new THREE.CylinderGeometry(cr, cr, ch, 64, 1, true, 0.75, Math.PI * 2 - 1.5); cw.translate(0, ch / 2, 0);
    const cwm = lam("tankSteelCut", () => ({ map: rep(steelTex(false), 7.2, 1.25), side: THREE.DoubleSide }));
    this.cutWall = new THREE.Mesh(cw, cwm); this.cutWall.castShadow = true; this.cutWall.receiveShadow = true;
    const cf = new THREE.CylinderGeometry(cr - 0.08, cr - 0.08, 1, 64); cf.translate(0, 0.5, 0);
    this.cutFill = new THREE.Mesh(cf, waveM); this.cutFill.castShadow = true; this.cutFill.receiveShadow = true;
    this.cutGroup.position.set(CUT[0], 0, CUT[2]); this.cutGroup.add(this.cutWall, this.cutFill); R.add(this.cutGroup);

    // near framing objects (Kenney props), toggled per frame
    for (const fg of FOREGROUND) {
      const o = kitClone(kit, fg.kit, fg.s ?? 1);
      if (!o) continue;
      o.position.set(...fg.pos); o.rotation.y = fg.yaw ?? 0; o.visible = false;
      this.fgs.push({ o, a: fg.a, b: fg.b }); R.add(o);
    }
  }

  private shotSun(id: number, s: ShotDef, L: LightPreset) {
    let v = this.sunCache.get(id);
    if (v) return v;
    let fx = 0, fz = 0;
    for (let f = s.a; f < s.b; f += 3) {
      const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
      fx += x / n; fz += z / n;
    }
    const n = Math.hypot(fx, fz) || 1; fx /= n; fz /= n;
    const az = THREE.MathUtils.degToRad(s.sunAz ?? L.az), el = THREE.MathUtils.degToRad(s.sunEl ?? L.el);
    const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
    v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
    this.sunCache.set(id, v);
    return v;
  }
  private actor(i: number) { while (this.actors.length <= i) this.actors.push(new Actor(this.root)); return this.actors[i]; }
  private fx(i: number) { while (this.fxs.length <= i) this.fxs.push(new Fx(this.root)); return this.fxs[i]; }

  private poseWave(w: WaveState) {
    this.waveMesh.visible = w.on;
    if (!w.on) return;
    const pos = this.waveGeo.attributes.position as THREE.BufferAttribute;
    for (let j = 0; j <= NZ; j++) {
      const z = ZA + j * DZ, h0 = waveH(w, z);
      for (let i = 0; i <= NX; i++) {
        const x = -XH + i * DX, e = smooth((Math.abs(x) - 4.3) / 0.9);
        pos.setXYZ(j * (NX + 1) + i, x, h0 * (1 - 0.22 * (x / XH) ** 2) * (1 - 0.85 * e), z);
      }
    }
    pos.needsUpdate = true; this.waveGeo.computeVertexNormals();
  }

  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene) {
    const t = f / 30, s = SHOTS[id - 1], L = LIGHTS[s.light];
    const c = camAt(id, f);
    cam.position.set(...c.pos); cam.up.set(0, 1, 0); cam.lookAt(...c.look); cam.rotateZ(c.roll);
    cam.fov = c.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    const focus = V(...c.look), dist = cam.position.distanceTo(focus);
    cam.layers.enable(NOINK);
    const K = LOOK[s.light], sunDir = this.shotSun(id, s, L);
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
    if (s.light === "golden") Rr = Math.max(Rr, 30);
    this.sun.position.copy(focus).addScaledVector(sunDir, 220); this.sun.target.position.copy(focus);
    const sc = this.sun.shadow.camera;
    sc.left = -Rr; sc.right = Rr; sc.top = Rr; sc.bottom = -Rr; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
    this.fill.intensity = 0;
    TONE.uLitCol.value.set(...L.lit); TONE.uShadeCol.value.set(...L.shade); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...K.bounce); TONE.uSat.value = K.sat;
    CHAR.uCharTint.value.set(...L.charTint); CHAR.uCharShade.value = L.charShade; CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad; CHAR.uSideTint.value.set(...L.sideTint);
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((deg) => THREE.MathUtils.degToRad(deg));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color); this.fog.near = L.fogNear; this.fog.far = L.fogFar;
    scene.fog = this.fog; scene.background = null;
    const showSun = s.light === "golden";
    this.sunDisc.visible = this.sunHalo.visible = showSun;
    if (showSun) {
      this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
      this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
      this.sunHalo.position.copy(this.sunDisc.position); this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
      (this.sunHalo.material as THREE.SpriteMaterial).color.set(L.sunDisc).multiplyScalar(1.3);
    }
    for (let i = 0; i < this.clouds.length; i++) {
      const m = this.clouds[i], mat = m.material as THREE.MeshBasicMaterial;
      m.lookAt(cam.position.x, m.position.y, cam.position.z); mat.map = this.cloudMaps[s.light][i % 4];
    }
    for (const g of this.fgs) g.o.visible = f >= g.a && f < g.b && g.a < s.b && g.b > s.a;

    // ---- tank ----
    const wreck = tankState(id) === "wreck", paint = paintAt(id, f);
    const brown = (id >= 9 && id <= 17);
    this.tankWall.visible = !wreck; this.tankRoof.visible = !wreck; this.tankWreck.visible = wreck; this.tankPool.visible = wreck;
    (this.tankWall.material as unknown) = brown ? this.brownM : this.steelM; (this.tankWreck.material as unknown) = this.brownM; (this.tankRoof.material as unknown) = brown ? this.brownM : this.steelM;
    const xr = paintX(id, paint);
    this.strips.forEach((m, i) => { m.visible = (id === 8 || id === 23) && this.stripX[i] < xr && paint > 0.001; });
    const bulge = bulgeAt(id, f);
    this.domes.forEach((d, i) => {
      d.visible = (id === 10 || id === 11) && !(i === 0 && f >= POP_F);
      d.scale.setScalar(0.4 + bulge * (1.0 + 0.5 * (i % 3) * 0.3));
    });
    const jetOn = (id === 10 || id === 11) && f >= POP_F;
    this.jet.visible = jetOn;
    if (jetOn) { const u = Math.min(1, (f - POP_F) / 20), len = 0.4 + 2.2 * u; this.jet.scale.set(1, len, 1); this.jet.position.set(-0.4, 2.3 - len * 0.4, WALL_Z + len * 0.45); this.jet.rotation.x = Math.PI / 2 + 0.7; }

    // ---- wave, hero house, cutaway ----
    this.poseWave(waveAt(id, f));
    const slide = id >= 12 && id <= 17 ? smooth((f - 945) / 70) : 0;
    this.heroHouse.position.set(-9.1 + 2.4 * slide, 0, -7 + 5.5 * slide); this.heroHouse.rotation.set(0, 0.28 * slide, 0.1 * slide);
    this.cutGroup.visible = id === 4 || id === 20;
    const fill = id === 4 ? 0.5 + 5.7 * smooth((f - 258) / 70) : 6.2;
    this.cutFill.scale.set(1, fill, 1);
    const bl = id === 20 ? 0.03 * smooth((f - 1690) / 60) + 0.004 * Math.sin(f * 1.7) * smooth((f - 1700) / 40) : 0;
    this.cutWall.scale.set(1 + bl, 1, 1 + bl);

    // ---- cast + effects ----
    const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
    const st = stage(id, f, { pos: cam.position, right });
    this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const tint = s.light === "golden" ? "#ffcf9e" : "#ffffff";
    let ai = 0;
    const used: Actor[] = [];
    for (const p of st.places) {
      const sc2 = p.scale ?? 1;
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
      const a = this.actor(ai++);
      const [w, h, k] = p.size ?? [300, 500, 0.5];
      a.r = this.pool.req(p.key, w, h, k, p.draw);
      a.mesh.visible = true; a.mesh.position.set(p.x, p.y, p.z);
      a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
      a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
      if (a.mat.emissiveMap) a.mat.emissive.set(tint);
      a.mesh.castShadow = L.actorShadow;
      used.push(a);
    }
    for (let i = ai; i < this.actors.length; i++) this.actors[i].mesh.visible = false;
    let fi = 0;
    const fused: Fx[] = [];
    for (const p of st.fx) {
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
      const e2 = this.fx(fi++);
      e2.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
      e2.use(!!p.soft); e2.mesh.visible = true; e2.mesh.position.set(p.x, p.y, p.z);
      if (p.flat) e2.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
      else { e2.mesh.quaternion.copy(cam.quaternion); e2.mesh.rotateZ(p.rot ?? 0); }
      e2.mesh.scale.set(p.w, p.h, 1);
      fused.push(e2);
    }
    for (let i = fi; i < this.fxs.length; i++) this.fxs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const e2 of fused) e2.bind();
    return focus;
  }
}
