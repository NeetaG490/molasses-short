// "Slower Than Molasses in January": shot timeline, cameras, DOF and the physical state of tank + wave.
// Everything is a pure function of (shot id, frame). 30 fps, 2030 frames. Timed to voice/words.json (voice 1.1x).
export const FPS = 30;
export const TOTAL = 2030;
export const D0 = 0; // ground level (build.ts default plinth height)
export type V3 = [number, number, number];
export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 4;

// ---------------- layout (metres; street runs along z, tank at its north end) ----------------
export const STREET_HALF = 5.5;           // house fronts at x = +-5.5
export const TANK: V3 = [0, 0, -46];
export const TANK_R = 13.7, TANK_H = 15;  // 90 ft x 50 ft
export const WALL_Z = TANK[2] + TANK_R;   // front of the wall, z = -32.3
export const CUT: V3 = [70, 0, -46];      // cutaway tank (shots 4, 20), off to the side
export const LAB: V3 = [-70, 0, -46];     // empty studio spot for the spoon / ketchup inserts (shots 18-19)
export const BURST_F = 893;               // "bursts"
export const POP_F = 803;                 // "groan": first rivet pops

export type Light = "day" | "golden";
export type ShotDef = { id: number; a: number; b: number; light: Light; sunAz?: number; sunEl?: number };
export const SHOTS: ShotDef[] = [
  { id: 1, a: 0, b: 119, light: "day" }, { id: 2, a: 119, b: 190, light: "day" }, { id: 3, a: 190, b: 258, light: "day" },
  { id: 4, a: 258, b: 343, light: "day" }, { id: 5, a: 343, b: 427, light: "day" }, { id: 6, a: 427, b: 505, light: "day" },
  { id: 7, a: 505, b: 562, light: "day" }, { id: 8, a: 562, b: 618, light: "day" }, { id: 9, a: 618, b: 718, light: "day" },
  { id: 10, a: 718, b: 824, light: "day" }, { id: 11, a: 824, b: 890, light: "day" }, { id: 12, a: 890, b: 994, light: "day" },
  { id: 13, a: 994, b: 1094, light: "day" }, { id: 14, a: 1094, b: 1173, light: "day" }, { id: 15, a: 1173, b: 1226, light: "day" },
  { id: 16, a: 1226, b: 1309, light: "day" }, { id: 17, a: 1309, b: 1419, light: "day" }, { id: 18, a: 1419, b: 1514, light: "day" },
  { id: 19, a: 1514, b: 1668, light: "day" }, { id: 20, a: 1668, b: 1802, light: "day" }, { id: 21, a: 1802, b: 1879, light: "golden", sunAz: 125, sunEl: 42 },
  { id: 22, a: 1879, b: 1950, light: "golden", sunAz: 125, sunEl: 42 }, { id: 23, a: 1950, b: TOTAL, light: "day" },
];
/** crossfades (frames) at place/time changes; white flash after the hook */
export const XFADE: Record<number, number> = {}; // hard cuts: a crossfade renders two scenes per frame (5x slower, timed out on CI)
export const FLASH_AT = 119;
export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [{ id: s.id - 1, alpha: 1 }, { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) }];
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};

// ---------------- physical state ----------------
/** molasses wave: front position zf, front height Hf, pool depth behind the front; `on` = drawn */
export type WaveState = { on: boolean; zf: number; Hf: number; pool: number };
const waveLaw = (tw: number): WaveState => ({ on: tw >= 0, zf: WALL_Z + 2 + (15.5 / 0.28) * (1 - Math.exp(-0.28 * tw)), Hf: 7.6 * Math.exp(-0.1 * tw), pool: 1.1 });
export const waveAt = (id: number, f: number): WaveState => {
  if (id === 1) return waveLaw(f / FPS + 0.5);                               // hook = flash-forward to the same wave
  if (id >= 12 && id <= 13) return waveLaw((f - BURST_F) / FPS);
  if (id === 14) return { on: true, zf: -6, Hf: 0.3, pool: 0.3 };
  if (id === 15) return { on: true, zf: -10 + (f - 1173) * 0.5, Hf: 1.5, pool: 0.5 };
  if (id >= 16 && id <= 17) return { on: true, zf: 4, Hf: 0.25, pool: 0.25 };
  return { on: false, zf: -60, Hf: 0, pool: 0 };
};
/** ground-level surface height of the wave at z */
export const waveH = (w: WaveState, z: number) => {
  if (!w.on || z > w.zf) return -0.3;
  const s = w.zf - z;
  const wall = w.pool + (w.Hf - w.pool) * Math.exp(-s / 2.4);
  return Math.max(w.pool * 0.4, wall * smooth(s / 0.8) * (z < WALL_Z - 6 ? 0.5 : 1));
};
export type TankState = "intact" | "wreck";
export const tankState = (id: number): TankState => (id >= 12 && id <= 17 ? "wreck" : "intact");
/** brown paint strips revealed 0..1 (shot 8 and the callback in shot 23); everything is brown after shot 8 until the burst */
export const paintAt = (id: number, f: number) => {
  if (id === 8) return smooth((f - 566) / 46);
  if (id === 23) return smooth((f - 1960) / 56);
  return id >= 9 && id <= 17 ? 1 : id === 8 ? 0 : 0;
};
/** x of the paint front / painter during the strokes (shot 8 sweeps the whole front, the callback only the framed part) */
export const paintX = (id: number, p: number) => (id === 23 ? -1.7 + 2.8 * p : -5.5 + 11 * p);
/** rivet bulge 0..1 (shots 10-11) */
export const bulgeAt = (id: number, f: number) => (id === 10 || id === 11 ? smooth((f - 740) / 70) : 0);

// ---------------- camera ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const mixC = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3, look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k, roll: a.roll + (b.roll - a.roll) * k,
});
const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });
const run = (keys: Key[], f: number) => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut ? full(k.s(f)) : mixC(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};
const pushK = (f: number, f0: number, rate: number, punch = 0, n = 30) => {
  const x = Math.max(0, f - f0);
  let s = rate * x;
  if (punch > rate) for (let i = 0; i < Math.min(x, n); i++) s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
  return Math.exp(-s);
};
/** camera slides toward the look point by factor k */
const dolly = (pos: V3, look: V3, k: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos: [look[0] + (pos[0] - look[0]) * k, look[1] + (pos[1] - look[1]) * k, look[2] + (pos[2] - look[2]) * k], look, ...rest });
const orbit = (c: V3, r: number, y: number, a: number, ly: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos: [c[0] + Math.sin(a) * r, y, c[2] + Math.cos(a) * r], look: [c[0], ly, c[2]], ...rest });
const at = (a: V3, b: V3, u: number): V3 => [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u];

const CAMS: Record<number, Key[]> = {
  1: [{ f: 0, s: (f) => dolly([0.8, 1.3, 13], [0, 2.6, -14], pushK(f, 0, 0.0035), { fov: 50, roll: 0.03 }) },
      { f: 66, dur: 10, s: (f) => dolly([0.5, 1.1, 11], [0, 2.2, -12], pushK(f, 66, 0.006), { fov: 36, roll: -0.06 }) }],
  2: [{ f: 119, s: (f) => dolly([3.2, 2.6, 36], [0, 6.2, -40], pushK(f, 119, 0.0028), { fov: 40 }) }],
  3: [{ f: 190, s: (f) => dolly([-2.8, 0.9, -10], [0, 9.5, -40], pushK(f, 190, 0.0025), { fov: 52, roll: 0.07 }) }],
  4: [{ f: 258, s: (f) => orbit(CUT, 38, 11, -0.5 + (f - 258) * 0.006, 3.0, { fov: 40 }) }],
  5: [{ f: 343, s: (f) => dolly([-2.4, 1.7, -26.2], [-1.0, 1.1, WALL_Z], pushK(f, 343, 0.006), { fov: 38 }) }],
  6: [{ f: 427, s: (f) => dolly([3.4, 0.9, -23.5], [-0.6, 1.0, -31], pushK(f, 427, 0.003), { fov: 44, roll: -0.03 }) }],
  7: [{ f: 505, s: (f) => dolly([0.4, 1.5, -19], [0, 1.45, -26], pushK(f, 505, 0.004), { fov: 36 }) }],
  8: [{ f: 562, s: (f) => dolly([2.2, 2.6, -23], [0.2, 4.6, -31.5], pushK(f, 562, 0.003), { fov: 44 }) }],
  9: [{ f: 618, s: (f) => dolly([0.5, 1.6, -20], [0, 1.65, -26.5], pushK(f, 618, 0.0035), { fov: 34 }) }],
  10: [{ f: 718, s: (f) => dolly([-1.8, 1.9, -15], [0.6, 3.0, -30], pushK(f, 718, 0.003), { fov: 44 }) },
       { f: 772, cut: true, s: (f) => dolly([-1.2, 1.9, -27.6], [-0.4, 2.3, WALL_Z], pushK(f, 772, 0.004, 0.012, 30), { fov: 28 }) }],
  11: [{ f: 824, s: (f) => dolly([0.9, 0.9, -21], [0, 6.0, -32.5], pushK(f, 824, 0.0035), { fov: 58, roll: 0.05 }) }],
  12: [{ f: 890, s: (f) => dolly([3.2, 1.4, 6], [0, 3.8, -20], pushK(f, 890, 0.002, 0.006, 25), { fov: 50, roll: -0.08 }) }],
  13: [{ f: 994, s: (f) => ({ pos: at([4, 15, 12], [6, 30, 36], glide((f - 994) / 100)), look: [0, 0, -4 + (f - 994) * 0.12], fov: 46 }) }],
  14: [{ f: 1094, s: (f) => dolly([0.6, 0.5, 6.8], [0, 0.14, 4], pushK(f, 1094, 0.004), { fov: 34 }) }],
  15: [{ f: 1173, s: (f) => dolly([0.6, 0.5, 6.8], [0, 0.4, 4], pushK(f, 1173, 0.002, 0.01, 20), { fov: 34, roll: 0.05 }) }],
  16: [{ f: 1226, s: (f) => dolly([0.5, 1.6, 1.5], [0, 1.4, -6.5], pushK(f, 1226, 0.0035), { fov: 38 }) }],
  17: [{ f: 1309, s: (f) => dolly([-5.6, 1.7, -28.2], [-8.6, 1.5, -34.4], pushK(f, 1309, 0.004), { fov: 30 }) }],
  18: [{ f: 1419, s: (f) => dolly([LAB[0] + 0.3, 1.2, LAB[2] + 4.6], [LAB[0] + 0.2, 1.1, LAB[2]], pushK(f, 1419, 0.004), { fov: 38 }) }],
  19: [{ f: 1514, s: (f) => dolly([LAB[0] + 0.8, 1.3, LAB[2] + 8.6], [LAB[0] + 0.8, 1.1, LAB[2]], pushK(f, 1514, 0.0025, 0.01, 25), { fov: 50 }) }],
  20: [{ f: 1668, s: (f) => orbit(CUT, 40, 12, 0.4 - (f - 1668) * 0.004, 3.0, { fov: 40 }) }],
  21: [{ f: 1802, s: (f) => dolly([0.2, 1.5, 4], [0, 1.3, -4], pushK(f, 1802, 0.003), { fov: 38 }) }],
  22: [{ f: 1879, s: (f) => dolly([0.3, 1.2, 2.2], [0, 1.0, -2], pushK(f, 1879, 0.004, 0.01, 25), { fov: 34 }) }],
  23: [{ f: 1950, s: (f) => dolly([-0.8, 2.5, -26], [0.5, 3.0, WALL_Z], pushK(f, 1950, 0.003), { fov: 38 }) }],
};
/** impact kicks: flip-sign shake that decays over 7 frames (camera height) */
export const KICKS = [66, POP_F, BURST_F, 1173, 1606, 1926, 2015];
export const camAt = (id: number, f: number): Cam => {
  const c = run(CAMS[id], f);
  for (const k of KICKS) if (f >= k && f < k + 7) { const a = 0.07 * (1 - (f - k) / 7) * (((f - k) & 1) ? -1 : 1); c.pos = [c.pos[0], c.pos[1] + a, c.pos[2]]; c.look = [c.look[0], c.look[1] + a * 0.6, c.look[2]]; }
  return c;
};

// ---------------- depth of field ----------------
const eyes = (z: number, y = 1.5, x = 0) => () => [x, y, z] as V3;
const DOF: { f: number; cInf: number; dur?: number; focus?: (f: number) => V3 }[] = [
  { f: 0, cInf: 12, focus: eyes(-1, 1.5) }, { f: 119, cInf: 0 }, { f: 190, cInf: 0 }, { f: 258, cInf: 10 }, { f: 343, cInf: 14 },
  { f: 427, cInf: 12, focus: eyes(-31, 1.0) }, { f: 505, cInf: 12, focus: eyes(-26, 1.6) }, { f: 562, cInf: 10 }, { f: 618, cInf: 12, focus: eyes(-26.5, 1.7) },
  { f: 718, cInf: 6 }, { f: 772, cInf: 13 }, { f: 824, cInf: 8, focus: eyes(-24, 1.0) }, { f: 890, cInf: 0 }, { f: 994, cInf: 0 },
  { f: 1094, cInf: 14 }, { f: 1173, cInf: 12 }, { f: 1226, cInf: 10, focus: eyes(-6.5, 1.6) }, { f: 1309, cInf: 13 },
  { f: 1419, cInf: 12 }, { f: 1514, cInf: 10 }, { f: 1668, cInf: 6 }, { f: 1802, cInf: 8, focus: eyes(-4, 1.4) }, { f: 1879, cInf: 12 }, { f: 1950, cInf: 12 },
];
export const dofAt = (f: number) => {
  let i = 0; while (i + 1 < DOF.length && f >= DOF[i + 1].f) i++;
  const d = DOF[i], p = DOF[Math.max(0, i - 1)];
  const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
  return { cInf: p.cInf + (d.cInf - p.cInf) * k, focus: d.focus };
};

/** near framing objects (Kenney props): visible while a <= f < b */
export type Fg = { a: number; b: number; kit: string; pos: V3; s?: number; yaw?: number };
export const FOREGROUND: Fg[] = [
  { a: 190, b: 258, kit: "cart", pos: [2.6, 0, -6], s: 1.3, yaw: 0.5 },
  { a: 427, b: 505, kit: "stall-red", pos: [5.6, 0, -22], s: 3.0, yaw: -1.2 },
];
